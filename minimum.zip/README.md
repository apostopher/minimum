Minimum Game
=========
A simple multiplayer game based on webSockets.

Version
---------
    Initial version 0.1.0
